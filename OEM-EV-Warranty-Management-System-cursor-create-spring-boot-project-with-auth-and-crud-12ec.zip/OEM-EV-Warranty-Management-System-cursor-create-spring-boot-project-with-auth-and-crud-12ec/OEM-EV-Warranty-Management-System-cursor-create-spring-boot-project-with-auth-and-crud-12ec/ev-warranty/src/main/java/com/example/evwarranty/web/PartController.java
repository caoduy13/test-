package com.example.evwarranty.web;

import com.example.evwarranty.domain.Part;
import com.example.evwarranty.service.PartService;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/parts")
public class PartController {
    private final PartService partService;

    public PartController(PartService partService) {
        this.partService = partService;
    }

    @GetMapping
    public List<Part> list() { return partService.findAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<Part> get(@PathVariable Long id) {
        return partService.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('STAFF')")
    public Part create(@RequestBody Part part) { return partService.save(part); }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('STAFF')")
    public ResponseEntity<Part> update(@PathVariable Long id, @RequestBody Part part) {
        return partService.findById(id)
                .map(existing -> {
                    existing.setName(part.getName());
                    existing.setPartNumber(part.getPartNumber());
                    return ResponseEntity.ok(partService.save(existing));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        partService.delete(id);
        return ResponseEntity.noContent().build();
    }
}

