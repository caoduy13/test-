package com.example.evwarranty.service;

import com.example.evwarranty.domain.Vehicle;
import com.example.evwarranty.repository.VehicleRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

@Service
public class VehicleService {
    private final VehicleRepository vehicleRepository;

    public VehicleService(VehicleRepository vehicleRepository) {
        this.vehicleRepository = vehicleRepository;
    }

    public List<Vehicle> findAll() { return vehicleRepository.findAll(); }
    public Optional<Vehicle> findById(Long id) { return vehicleRepository.findById(id); }
    public Vehicle save(Vehicle v) { return vehicleRepository.save(v); }
    public void delete(Long id) { vehicleRepository.deleteById(id); }
}

