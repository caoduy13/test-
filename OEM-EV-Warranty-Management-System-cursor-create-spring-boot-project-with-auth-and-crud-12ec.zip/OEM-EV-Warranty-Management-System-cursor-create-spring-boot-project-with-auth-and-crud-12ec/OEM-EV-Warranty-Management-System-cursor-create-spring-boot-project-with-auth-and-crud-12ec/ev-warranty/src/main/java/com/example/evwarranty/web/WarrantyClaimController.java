package com.example.evwarranty.web;

import com.example.evwarranty.domain.WarrantyClaim;
import com.example.evwarranty.service.WarrantyClaimService;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/claims")
public class WarrantyClaimController {
    private final WarrantyClaimService service;

    public WarrantyClaimController(WarrantyClaimService service) {
        this.service = service;
    }

    @GetMapping
    public List<WarrantyClaim> list() { return service.findAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<WarrantyClaim> get(@PathVariable Long id) {
        return service.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('STAFF') or hasRole('TECHNICIAN')")
    public WarrantyClaim create(@RequestBody WarrantyClaim claim) { return service.save(claim); }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('STAFF') or hasRole('TECHNICIAN')")
    public ResponseEntity<WarrantyClaim> update(@PathVariable Long id, @RequestBody WarrantyClaim claim) {
        return service.findById(id)
                .map(existing -> {
                    existing.setClaimNumber(claim.getClaimNumber());
                    existing.setVehicle(claim.getVehicle());
                    existing.setPart(claim.getPart());
                    existing.setStatus(claim.getStatus());
                    existing.setDescription(claim.getDescription());
                    return ResponseEntity.ok(service.save(existing));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('STAFF')")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}

