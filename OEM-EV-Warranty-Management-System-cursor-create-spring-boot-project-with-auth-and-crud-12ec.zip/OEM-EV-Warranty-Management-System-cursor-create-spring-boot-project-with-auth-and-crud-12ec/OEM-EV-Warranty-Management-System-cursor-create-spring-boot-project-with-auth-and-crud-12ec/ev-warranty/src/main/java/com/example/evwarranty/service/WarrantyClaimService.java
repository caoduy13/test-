package com.example.evwarranty.service;

import com.example.evwarranty.domain.WarrantyClaim;
import com.example.evwarranty.repository.WarrantyClaimRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

@Service
public class WarrantyClaimService {
    private final WarrantyClaimRepository repository;

    public WarrantyClaimService(WarrantyClaimRepository repository) {
        this.repository = repository;
    }

    public List<WarrantyClaim> findAll() { return repository.findAll(); }
    public Optional<WarrantyClaim> findById(Long id) { return repository.findById(id); }
    public WarrantyClaim save(WarrantyClaim wc) { return repository.save(wc); }
    public void delete(Long id) { repository.deleteById(id); }
}

