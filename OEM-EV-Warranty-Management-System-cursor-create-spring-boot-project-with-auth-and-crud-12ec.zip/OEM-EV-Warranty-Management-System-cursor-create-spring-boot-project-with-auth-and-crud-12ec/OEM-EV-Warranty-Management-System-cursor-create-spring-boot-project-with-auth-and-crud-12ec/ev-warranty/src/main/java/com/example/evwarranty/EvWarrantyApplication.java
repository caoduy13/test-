package com.example.evwarranty;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvWarrantyApplication {
    public static void main(String[] args) {
        SpringApplication.run(EvWarrantyApplication.class, args);
    }
}

