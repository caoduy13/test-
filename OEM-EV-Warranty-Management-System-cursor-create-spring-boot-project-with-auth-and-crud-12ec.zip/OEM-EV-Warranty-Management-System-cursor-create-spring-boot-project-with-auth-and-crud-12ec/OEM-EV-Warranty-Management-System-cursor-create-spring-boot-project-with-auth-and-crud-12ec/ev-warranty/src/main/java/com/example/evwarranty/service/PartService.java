package com.example.evwarranty.service;

import com.example.evwarranty.domain.Part;
import com.example.evwarranty.repository.PartRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

@Service
public class PartService {
    private final PartRepository partRepository;

    public PartService(PartRepository partRepository) {
        this.partRepository = partRepository;
    }

    public List<Part> findAll() { return partRepository.findAll(); }
    public Optional<Part> findById(Long id) { return partRepository.findById(id); }
    public Part save(Part p) { return partRepository.save(p); }
    public void delete(Long id) { partRepository.deleteById(id); }
}

