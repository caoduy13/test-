package com.example.evwarranty.domain;

public enum Role {
    ROLE_ADMIN,
    ROLE_STAFF,
    ROLE_TECHNICIAN
}

