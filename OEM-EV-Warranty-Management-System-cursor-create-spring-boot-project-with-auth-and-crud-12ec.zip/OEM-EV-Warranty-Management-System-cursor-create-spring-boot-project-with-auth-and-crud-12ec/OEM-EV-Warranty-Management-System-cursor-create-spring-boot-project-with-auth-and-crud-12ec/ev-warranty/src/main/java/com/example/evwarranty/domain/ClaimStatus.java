package com.example.evwarranty.domain;

public enum ClaimStatus {
    PENDING,
    APPROVED,
    REJECTED,
    COMPLETED
}

