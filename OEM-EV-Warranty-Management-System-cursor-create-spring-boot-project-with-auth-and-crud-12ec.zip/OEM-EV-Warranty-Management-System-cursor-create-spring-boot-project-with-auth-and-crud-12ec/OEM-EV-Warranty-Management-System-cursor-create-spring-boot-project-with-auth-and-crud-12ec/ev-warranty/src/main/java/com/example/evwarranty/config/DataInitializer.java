package com.example.evwarranty.config;

import com.example.evwarranty.domain.*;
import com.example.evwarranty.repository.*;
import java.util.Set;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initData(UserRepository userRepo, CustomerRepository customerRepo,
                               VehicleRepository vehicleRepo, PartRepository partRepo,
                               WarrantyClaimRepository claimRepo,
                               PasswordEncoder passwordEncoder) {
        return args -> {
            if (userRepo.count() == 0) {
                User admin = new User();
                admin.setUsername("admin");
                admin.setPassword(passwordEncoder.encode("admin123"));
                admin.setRoles(Set.of(Role.ROLE_ADMIN));
                userRepo.save(admin);

                User staff = new User();
                staff.setUsername("staff");
                staff.setPassword(passwordEncoder.encode("staff123"));
                staff.setRoles(Set.of(Role.ROLE_STAFF));
                userRepo.save(staff);
            }

            Customer c1 = new Customer();
            c1.setName("Nguyen Van A");
            c1.setEmail("a@example.com");
            c1.setPhone("090000001");
            customerRepo.save(c1);

            Part p1 = new Part();
            p1.setPartNumber("BMS-001");
            p1.setName("Battery Management System");
            partRepo.save(p1);

            Vehicle v1 = new Vehicle();
            v1.setVin("VIN1234567890");
            v1.setModel("EV-Alpha");
            v1.setYear(2024);
            v1.setCustomer(c1);
            vehicleRepo.save(v1);

            WarrantyClaim cl = new WarrantyClaim();
            cl.setClaimNumber("CLM-0001");
            cl.setVehicle(v1);
            cl.setPart(p1);
            cl.setStatus(ClaimStatus.PENDING);
            cl.setDescription("Battery error code P0A80");
            claimRepo.save(cl);
        };
    }
}

