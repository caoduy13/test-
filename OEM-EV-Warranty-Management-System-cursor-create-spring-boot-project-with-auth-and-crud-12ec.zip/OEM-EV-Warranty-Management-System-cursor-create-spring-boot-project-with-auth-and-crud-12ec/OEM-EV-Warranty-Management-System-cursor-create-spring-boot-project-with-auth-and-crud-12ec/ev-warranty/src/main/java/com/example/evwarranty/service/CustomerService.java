package com.example.evwarranty.service;

import com.example.evwarranty.domain.Customer;
import com.example.evwarranty.repository.CustomerRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {
    private final CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public List<Customer> findAll() { return customerRepository.findAll(); }
    public Optional<Customer> findById(Long id) { return customerRepository.findById(id); }
    public Customer save(Customer c) { return customerRepository.save(c); }
    public void delete(Long id) { customerRepository.deleteById(id); }
}

